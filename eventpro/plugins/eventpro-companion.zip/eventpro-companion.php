<?php 
/**
 * Plugin Name:   EventPro Companion
 * Plugin URI:    https://github.com/sajjad-limon
 * Description:   Companion plugin for the eventpro theme
 * Version:       1.0
 * Author:        Sajjad Limon
 * Author URI:    https://github.com/sajjad-limon
 * Text Domain:   eventpro-companion
 */

function eventpro_register_my_cpts() {

	/**
	 * Post Type: Events.
	 */

	$labels = [
		"name" => esc_html__( "Events", "eventpro" ),
		"singular_name" => esc_html__( "Event", "eventpro" ),
		"add_new" => esc_html__( "Add New Event", "eventpro" ),
		"featured_image" => esc_html__( "Event Poster", "eventpro" ),
		"set_featured_image" => esc_html__( "Set Poster", "eventpro" ),
		"remove_featured_image" => esc_html__( "Remove Poster", "eventpro" ),
		"use_featured_image" => esc_html__( "Use Poster", "eventpro" ),
	];

	$args = [
		"label" => esc_html__( "Events", "eventpro" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"rest_namespace" => "wp/v2",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"can_export" => false,
		"rewrite" => [ "slug" => "event", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-calendar",
		"supports" => [ "title", "editor", "thumbnail", "custom-fields" ],
		"taxonomies" => [ "category" ],
		"show_in_graphql" => false,
	];

	register_post_type( "event", $args );
}

add_action( 'init', 'eventpro_register_my_cpts' );


// register custom taxonomy
function eventpro_register_my_taxes() {

	/**
	 * Taxonomy: Months.
	 */

	$labels = [
		"name" => esc_html__( "Months", "eventpro" ),
		"singular_name" => esc_html__( "Month", "eventpro" ),
	];

	
	$args = [
		"label" => esc_html__( "Months", "eventpro" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => false,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'month', 'with_front' => true, ],
		"show_admin_column" => false,
		"show_in_rest" => true,
		"show_tagcloud" => false,
		"rest_base" => "month",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"rest_namespace" => "wp/v2",
		"show_in_quick_edit" => false,
		"sort" => false,
		"show_in_graphql" => false,
	];
	register_taxonomy( "month", [ "event" ], $args );

	/**
	 * Taxonomy: Weeks.
	 */

	$labels = [
		"name" => esc_html__( "Weeks", "eventpro" ),
		"singular_name" => esc_html__( "Week", "eventpro" ),
	];

	
	$args = [
		"label" => esc_html__( "Weeks", "eventpro" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => false,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'events', 'with_front' => false, ],
		"show_admin_column" => false,
		"show_in_rest" => true,
		"show_tagcloud" => false,
		"rest_base" => "week",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"rest_namespace" => "wp/v2",
		"show_in_quick_edit" => false,
		"sort" => false,
		"show_in_graphql" => false,
	];
	register_taxonomy( "week", [ "event" ], $args );
}
add_action( 'init', 'eventpro_register_my_taxes' );