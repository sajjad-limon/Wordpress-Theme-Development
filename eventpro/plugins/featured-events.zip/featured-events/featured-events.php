<?php
/*
 * Plugin Name:     Featured Events
 * Plugin URI:      https://github.com/sajjad-limon
 * Description:     List all events with new Eventpro 2.0 style, shortcode [featured_events slug="category_slug" list_events="number"]
 * Version:         1.0
 * Author:          Sajjad Limon
 * Author URI:      https://github.com/sajjad-limon
 * License:         GPL v2 or later
 * License URI:     https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:     featured-events
 * Domain Path:     /languages
 */

add_shortcode('featured_events', 'get_featured_events');

?>

<section class="featured">
  <div class="container">
    <h1 class="featured-text"> <?php echo esc_html(' Featured Events'); ?> </h1>
    <div class="main-featured">
      <div class="row">

        <?php

        function get_featured_events($param)
        {
          $eventpro_args = new WP_Query(array(
            'post_type' => 'event',
            'category_name' => 'featured',
            'posts_per_page' => 6,
            'order_by' => 'post_date',
            'order' => 'ASC',
          ));

          //print_r($eventpro_args);
        
          while ($eventpro_args->have_posts()) {
            $eventpro_args->the_post();

            ?>

            <div class="col-md-6 col-lg-4">
              <div class="featured-mother">
                <div class="featured-date">
                  <div class="part-a">
                    <h3>
                      <?php echo get_post_meta(get_the_ID(), 'evm_date', true); ?>
                    </h3>
                    <h2>
                      <?php echo get_post_meta(get_the_ID(), 'evm_started', true); ?>
                    </h2>
                  </div>
                  <div class="part-b">
                    <i class="fas fa-map-marker-alt"></i>
                    <p> <?php echo get_post_meta(get_the_ID(), 'evm_venue', true); ?></p>
                  </div>
                </div>
                <div class="featured-image">
                  <img src="<?php the_post_thumbnail(); ?>" alt="">
                  <h1 class="text-image"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                </div>
              </div>
            </div>

          <?php }
        }
        ;
        wp_reset_query(); ?>


      </div>
    </div>
  </div>
</section>