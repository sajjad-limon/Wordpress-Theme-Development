jQuery(document).ready(function () {
  jQuery("#evm_date").datepicker({
    dateFormat: "d",
  });
});

jQuery(document).ready(function () {
  jQuery("#evm_started").datepicker({
    dateFormat: "M",
  });
});

